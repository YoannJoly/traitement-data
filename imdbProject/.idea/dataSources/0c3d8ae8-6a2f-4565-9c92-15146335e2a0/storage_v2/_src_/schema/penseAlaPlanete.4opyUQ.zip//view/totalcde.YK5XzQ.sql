create definer = Yoann@localhost view totalcde as
select `pensealaplanete`.`commande`.`idCde`                                                   AS `idCde`,
       `pensealaplanete`.`client`.`nomClt`                                                    AS `nomClt`,
       `pensealaplanete`.`client`.`prenomClt`                                                 AS `prenomClt`,
       `pensealaplanete`.`commande`.`dateCde`                                                 AS `dateCde`,
       sum((`pensealaplanete`.`art_com`.`prixCdeArt` * `pensealaplanete`.`art_com`.`qteCde`)) AS `total`
from ((`pensealaplanete`.`commande` join `pensealaplanete`.`client` on ((`pensealaplanete`.`client`.`idClt` =
                                                                         `pensealaplanete`.`commande`.`idClt`))) join `pensealaplanete`.`art_com`
      on ((`pensealaplanete`.`art_com`.`idCde` = `pensealaplanete`.`commande`.`idCde`)))
group by `pensealaplanete`.`commande`.`idCde`;

