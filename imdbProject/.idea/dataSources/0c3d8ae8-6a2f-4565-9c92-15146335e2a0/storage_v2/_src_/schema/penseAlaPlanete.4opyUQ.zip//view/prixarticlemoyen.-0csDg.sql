create definer = Yoann@localhost view prixarticlemoyen as
select `pensealaplanete`.`article`.`idArt`           AS `idArt`,
       `pensealaplanete`.`article`.`libArt`          AS `libArt`,
       avg(`pensealaplanete`.`art_com`.`prixCdeArt`) AS `prixMoyen`
from (`pensealaplanete`.`article` join `pensealaplanete`.`art_com`
      on ((`pensealaplanete`.`article`.`idArt` = `pensealaplanete`.`art_com`.`idArt`)))
group by `pensealaplanete`.`art_com`.`idArt`;

